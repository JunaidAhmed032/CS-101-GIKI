#include <iostream>
using namespace std;
string anglescheck(int a , int b, int c){
	if(a<90 && b<90 && c<90){
		return "acute";
	}
	if(a==90 || b==90 || c==90){
		return "right";
	}
	else if (a>90 ||b>90 ||c>90)
		return "obtuse";
	
}

int main(){
	int a,b,c; //sides of triangle
	int a1,b1,c1; // angles of triangle
	
	cout<<"Enter the sides and angles of triangles :"<<endl;
	cout<<"side 1 :";
	cin>>a;
	cout<<"side 2 :";
	cin>>b;
	cout<<"side 3 :";
	cin>>c;
	cout<<"\n Enter the angles of triangle :\n";
	cout<<"angle 1 : ";
	cin>>a1;
	cout<<"angle 2 : ";
	cin>>b1;
	cout<<"angle 3 : ";
	cin>>c1;
	
	int anglesum=a1+b1+c1;
	if(anglesum!=180){
		cout<<"it is not a tringle !!";
		return 0;
	}
	if(a==b&& b==c && a==c){
		cout<<"it is an equilateral triangle & ";
	}
	else if(a==b || b==c || c==a){
		cout<<"it is an isosceles triangle & ";
	}
	else if(a!=b && b!=c && c!=a ){
		cout<<"it is a scalence triangle & ";
	}
	
	cout<<anglescheck(a1 ,b1, c1);
	return 0;
}