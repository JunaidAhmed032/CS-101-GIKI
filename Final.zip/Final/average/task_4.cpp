#include <iostream>
#include <fstream>
using namespace std;
void brighteststar(float arr[][4],int row){
	int brightest;
		if(arr[0][2]<arr[1][2] && arr[0][2]<arr[2][2]){
			cout<<"brightest="<< arr[0];
		}
		if(arr[1][2]<arr[0][2] && arr[1][2]<arr[2][2]){
			cout<<"brightest="<< arr[0];
		}
		if(arr[2][2]<arr[0][2] && arr[2][2]<arr[1][2]){
			cout<<"brightest="<<arr[2];
		}

}
int main(){
	int row=3;
	float arr[row][4];
	cout<<"enter the properties of the 3 stars :";
	cout<<"At first enter Right Ascension ,then declination,then magnitude and at last spectral type\n";
	
	cout<<"note:\n for spectral types of the stars use following instructions\nfor G type entyer 1 .\nfor a type enter 2\n for b type enter 3\nfor m type 4 "<<endl;
	for(int i = 0 ; i<row; i++){
		for(int j=0; j<4; j++){
			cin>>arr[i][j];
		}               
	}
	brighteststar(arr,row);
		
	
		
		
		
		
		
		
		
		
		
		
		
		
	ofstream out("stardata.txt");
	out.open("stardata.txt");
	if(out.is_open()){
		out<<arr;
		
	}
	
	

	
	
	return 0;
}