#include <iostream>
using namespace std;


int  main(){
	int playersb=10;
//	cout<<"Enter the number of player : ";
	//cin>>players;
	int arr[playersb]={1,2,3,4,5,6,7,8,9,10};
	cout<<"enter k";
	int k;
	cin>>k;
	int initial=0;
	int i=initial;
	int players=playersb;
	while (players>1){
		arr[i+k]=0;
		i=i+k+1;
		players--;
		if(i>=9){
			i=++initial;
		}
	}
	
	for(int i=0; i<playersb; i++){
		if(arr[i]!=0){
			cout<<arr[i];
		}
	}
	

	
	
	return 0;
}