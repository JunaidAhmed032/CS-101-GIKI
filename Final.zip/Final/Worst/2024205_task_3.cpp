#include <iostream>
using namespace std;

int fib(int n)
{
	if (n == 0 || n == 1)
	{
		return 1;
	}
	
	if (n > 1)
	{
	return fib (n-2) + fib (n-3);
	}
}

int main()
{
	cout << fib (8);
}