#include <iostream>
using namespace std;

int main(){
	int testCases = 0;
	cout << "Enter the number of test cases: ";
	cin >> testCases;
	
	while (testCases > 0){
		int steps = 0;
		int n = 0;
		int sword = 0;
		int remaining = 0;
		cout << "Enter the amount of terrorists: ";
		cin >> n;
		remaining = n;
		
		if (n < 1){
			cout << "Invalid input." << endl;
			continue;
		}
		
		cout << "Enter the steps for elimination: ";
		cin >> steps;
		
		if (steps < 1){
			cout << "Invalid input."<< endl;
			continue;
		}
		
		int nArray[n] = {0};
		for (int i = 1; i <= n; i++){
			nArray[i - 1] = i; 
		}
		
		while (remaining > 1){
			int nearestAlive = 0;
			int overflow = 0;
			int skips = steps;
			for (int i = 1; i < 2 * n; i++){
				
				if(nArray[sword+i-overflow] == sword + 1){
					continue;
				}
				
				if (sword + i > n - 1){
					overflow = n;
					if (sword + i > 2 * n - 1){
						overflow = 2 * n;
					}
				}
				else{
					overflow = 0;
				}
				
				if(nArray[sword + i - overflow] != -1){
					skips -= 1;
					if (skips == 0){
						nearestAlive = sword + i - overflow;
						break;
						skips = steps;
					}
				}
			}
			
			cout << "Terrorist " << nArray[sword] << " eliminates terrorist " << nArray[nearestAlive] << endl;
			nArray[nearestAlive] = -1;
			remaining -= 1;
			
			overflow = 0;
			skips = steps;
			if (remaining == 1){
				cout << nArray[sword] << " survives." << endl;
			}
			else{
				for (int i = 1; i < 2 * n; i++){
					if (sword + i > n - 1){
						overflow = n;
						if (sword + i > 2 * n - 1){
							overflow = 2 * n;
						}
					}
					if(nArray[sword + i - overflow] != -1 && nArray[sword + i - overflow] != sword + 1){
						skips -= 1;
						if (skips == 0){
							skips = steps;
							sword = sword + i - overflow;
							break;
						}
					}
				}
			}
		}
		testCases -= 1;
	}
}