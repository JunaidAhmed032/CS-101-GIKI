#include <iostream>
using namespace std;

int main(){
	//variable declaration & user input
	float sideA, sideB, sideC = 0;
	float perpendicular, base, hypotenus = 0;
	
	cout << "Enter the length of side A: " << endl;
	cin >> sideA;
	cout << "Enter the length of side B: " << endl;
	cin >> sideB;
	cout << "Enter the length of side C: " << endl;
	cin >> sideC;
	
	//using a flag to check which side is the biggest
	int greatestSide = 0; // sideA is the biggest by default
	if(sideB > sideA && sideB > sideC){
		greatestSide = 1; //if sideB is bigger than change the flag
	}
	else if (sideC > sideA && sideC > sideB){
		greatestSide = 2; // same for C
	}
	

	//switch case is used to assign the values for the hypotenus, perpendicular & base of the triangle
	switch (greatestSide){
		case 0:
			hypotenus = sideA;
			perpendicular = sideB;
			base = sideC;
			break;
		case 1:
			hypotenus = sideB;
			perpendicular = sideA;
			base = sideC;
			break;
		case 2:
			hypotenus = sideC;
			perpendicular = sideB;
			base = sideA;
			break;
		default:
			cout << "something went wrong" << endl;
			break;
	}
	
	//if the combined sum of the two smaller sides are equal to or bigger than the biggest side than the triangle will be invalid
	if (perpendicular + base <= hypotenus){
		cout << "Invalid triangle" << endl;
			return 1;
	}
	
	//if all sides are equal then equalitarel, else if 2 are equal then isocoleels, else scalene
	if (sideA == sideB && sideB == sideC){
		cout << "Equilateral & ";
	}
	else if (sideA == sideB || sideB == sideC || sideC == sideA){
		cout << "Isosceles & ";
	}
	else{
		cout << "Scalene & ";
	}
	
	//if pythagorean theorum checks out then right, else if c^2 > b^2 + a^2 then it is obtuse since the angle of the hypotenus will be > pi/2
	if (perpendicular * perpendicular + base * base == hypotenus * hypotenus){
		cout << "Right" << endl;
	}
	else if (perpendicular * perpendicular + base * base < hypotenus * hypotenus){
		cout << "Obtuse" << endl;
	}
	else{
		cout << "Acute" << endl;
	}
	
	return 0;
}