#include <iostream>
using namespace std;

//recursion used to generate fibonacci
int fibonacci(int n){
	if (n == 0 || n == 1){
		return n;
	}
	else{
		return fibonacci(n-1) + fibonacci(n - 2);
	}
}

int main(){
	//user input + variable declaration
	int n = 0;
	cout << "Enter the amount of terms of fibonacci to generate: ";
	cin >> n;
	
	if (n < 0){
		cout << "Invalid input" << endl;
		return 1;
	}
	
	//for loop used to print output
	for (int i = 0; i < n; i++){
		cout << fibonacci(i) << "  ";
	}
}