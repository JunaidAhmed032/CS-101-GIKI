#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

char NumToChar(int inputNum);
int CharToNum(char inputChar);

int main(){
	ofstream outputFile("output.txt");
	char starType = 'G';
	if(!outputFile.is_open()){
		cerr << "masla hai" << endl;
		return 1;
	}
	
	int n = 0;
	cout << "How many stars do you wish to input: ";
	cin >> n;
	
	if (n < 1){
		cout << "Invalid input.";
		return 1;
	}
	
	float starsArray[n][4] = {0};
	for (int i = 0; i < n; i++){
	
		outputFile << "Star Number: " << i + 1 << endl;
		cout << "Enter the Right Acension of the star " << i + 1 << ": ";
		cin >> starsArray[i][0];
		outputFile << "RA :" << starsArray[i][0] << endl;
		
		cout << "Enter the Declination of the star " << i + 1<< ": ";
		cin >> starsArray[i][1];
		outputFile << "Dec :" << starsArray[i][1] << endl;
		
		cout << "Enter the Maginitude of the star " << i + 1 << ": ";
		cin >> starsArray[i][2];
		outputFile << "Magnitude :" << starsArray[i][2] << endl;
		
		cout << "Enter the Spectral Type of the star " << i + 1<< ": ";
		cin >> starType;
		starsArray[i][3] = CharToNum(starType);
		outputFile << "Type :" << NumToChar(starsArray[i][3]) << endl;
		cout << endl;
	}
	
	outputFile << endl << endl;
	
	int typeListed = 0;
	int brightest = 0;
	float inputRA = 0;
	float inputDec = 0;
	float leastDis = 1000000000000000;
	int closestStar = 0;
		
	cout << "Enter the Spectral Type you wish to see: ";
	cin >> starType;
	typeListed = CharToNum(starType);

	if (typeListed < 0 || typeListed > 3){
		cout << "Invalid input, putting in type G as default" << endl;
		typeListed = 0;
	}
	
	cout << "Enter the RA of the point you wish to see: ";
	cin >> inputRA;
	cout << "Enter the Dec of the point you wish to see: ";
	cin >> inputDec;
	
	for (int i = 0; i < n; i++){
		if (starsArray[i][2] < starsArray[brightest][2]){
			brightest = i;
		}
	}
	
	for (int i = 0; i < n; i++){
		float vDis = starsArray[i][0] - inputRA;
		float hDis = starsArray[i][1] - inputDec;
		float totalDis = pow( (vDis*vDis + hDis*hDis), 0.5  );
		if (totalDis < leastDis){
			leastDis = totalDis;
			closestStar = i;
		}
	}
	
	cout << "The brightest star is: " << endl;
	cout << "Star " << brightest + 1 << " RA: " << starsArray[brightest][0] <<  " Dec: " <<  starsArray[brightest][0] << " Magnitude: " << starsArray[brightest][2] << " Type: " << NumToChar(starsArray[brightest][3]) << endl;
	
	cout << "The closest star to RA: " << inputRA << " Dec: " << inputDec << " is: " << endl;
	cout << "Star " << closestStar + 1 << " RA: " << starsArray[closestStar][0] <<  " Dec: " <<  starsArray[closestStar][0] << " Magnitude: " << starsArray[closestStar][2] << " Type: "<<  NumToChar(starsArray[closestStar][3]) << endl;

	cout << "All stars of chosen type: " << endl;
	for (int i = 0; i < n; i++){
		if (starsArray[i][3] == typeListed){
			cout << "Star " << i + 1 << " RA: " << starsArray[i][0] <<  " Dec: " << starsArray[i][0] << " Magnitude: " <<  starsArray[i][2] << " Type: " << NumToChar(starsArray[i][3]) << endl;
		}
	}
	
	outputFile << "The brightest star is: " << endl;
	outputFile << "Star " << brightest + 1 << " RA: " << starsArray[brightest][0] <<  " Dec: " <<  starsArray[brightest][0] << " Magnitude: " << starsArray[brightest][2] << " Type: " << starsArray[brightest][3] << endl;
	
	outputFile << "The closest star to RA: " << inputRA << " Dec: " << inputDec << " is: " << endl;
	outputFile << "Star " << closestStar + 1 << " RA: " << starsArray[closestStar][0] <<  " Dec: " <<  starsArray[closestStar][0] << " Magnitude: " << starsArray[closestStar][2] << " Type: "<<  starsArray[closestStar][3] << endl;

	outputFile << "All stars of chosen type: " << endl;
	for (int i = 0; i < n; i++){
		if (starsArray[i][3] == typeListed){
			outputFile << "Star " << i + 1 << " RA: " << starsArray[i][0] <<  " Dec: " << starsArray[i][0] << " Magnitude: " <<  starsArray[i][2] << " Type: " << starsArray[i][3] << endl;
		}
	}
	
	outputFile.close();
	return 0;
}

char NumToChar(int inputNum){
	switch(inputNum){
		case 0:
			return 'G';
			break;
		case 1:
			return 'B';
			break;
		case 2:
			return 'A';
			break;
		case 3:
			return 'M';
			break;
		default:
			cout << "masla" << endl;
			return 'a';
			break;
	}
}
int CharToNum(char inputChar){
		switch(inputChar){
		case 'G':
			return 0;
			break;
		case 'B':
			return 1;
			break;
		case 'A':
			return 2;
			break;
		case 'M':
			return 3;
			break;
		default:
			cout << "masla" << endl;
			return -1;
			break;
	}
}