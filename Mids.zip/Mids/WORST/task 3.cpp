#include<iostream>
using namespace std;
int main(){
	int days; //declaring variables
	cout<<"Enter total number of days watered"<<endl; //taking number of days
	cin>>days;
	int h;
	bool watered=1;
	
	for(int i=1; i<days; i++) //trying to use loop to calculate output
{if (  i%2==0)
	{
	h= h+ i;}}
	cout<<h;
	return 0;}