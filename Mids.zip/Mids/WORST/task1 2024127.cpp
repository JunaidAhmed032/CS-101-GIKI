#include<iostream>
using namespace std;
int main (){
	string name;
	double base, hours, hourly_rate, rating, number, overtime, bonus;
	cout<<"Enter employee name: "<<endl;
	cin>>name;
	cout<<"Enter number of hours worked: "<<endl; //taking input
	cin>>hours;
	cout<<"Enter performance rating (1-5): "<<endl;
	cin>>rating;
	cout<<"Enter number of years worked: "<<endl;
	cin>>number;
	hourly_rate= 30;
	if(hours<=40)
	{ base=hours*40;
	cout<<"Base Salary: "<<base<<" $";}
	if (hours>40)
	{ overtime=(hours-40)*hourly_rate*1.5;
	cout<<"Overtime pay: "<<overtime<<" $"<<endl;}
	
	if (rating==4 || rating==5)
	{ bonus=(10*base/100)+base;
	cout<<"Bonus: "<<bonus<<" $"<<endl;}
	if (number>10)
	{cout<<"Loyalty bonus= 1000 $"<<endl;	} //showing output
	return 0;}