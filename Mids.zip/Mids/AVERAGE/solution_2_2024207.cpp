//diamond structure maker
#include<iostream>

using namespace std;

int main(){
	int num;
	cout<<"N= ";
	cin>>num;
	//number of rows entered
	for(int i=0;i<=num-1;i++){
	
		for(int k=0;k<=num-i;k++){
			
			cout<<" ";
		//spacing for accuracy	
		}
		for(int j=0;j<=(2*i);j++){
			cout<<"*";	
			
		//such a half triangle will be made
			
			
			
		}
		cout<<endl;
	}
	
		for(int i=num-2;i>=0;i--){
			
		for(int k=0;k<=num-i;k++){
			
			cout<<" ";//spacing for accuracy	
		}
		for(int j=0;j<=(2*i);j++){
			cout<<"*";	
		//lower triangle will be made
			
			
			
			
			
		}
		cout<<endl;
		
	
		
	}
	
	
	
}
