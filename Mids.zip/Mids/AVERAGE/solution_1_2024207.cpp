//TOTAL COMPENSATION CALCULATOR
#include<iostream>
#include<string>

using namespace std;

int main(){
	//initialization,declaration the variable
	double base_salary;//base_salary enter
	double over_time_pay=0;
	double hours_worked;
	double overtimehrs=0;
	double hourly_pay;
	int performance_rating;
	int year_servicing;
	int loyalty_bonus=0;
	string s1;
	double hours=1.5;
	double total_pay=0;
	cout<<"ENTER EMPLOYEE NAME:\t";//name of employe must be entered
	cin>>s1;
	cout<<"BASE SALARY:\t$";
	cin>>base_salary;
	cout<<"HOURS WORKED:\t$";
	cin>>hours_worked;
	cout<<"hourly_pay  : $ ";
	cin>>hourly_pay;
	cout<<"PERFORMANCE RATE:\t";
	cin>>performance_rating;
	cout<<" year_servicing ";
	cin>> year_servicing;

	double bonus_of_performance=0;	
	
	
	if(base_salary>0&&hours_worked>0&&performance_rating>0&&year_servicing>0){
		//if hours worked>40 bonus will recieved
		if( hours_worked>40){
		overtimehrs=hours_worked-40;
		over_time_pay=overtimehrs*hourly_pay*(hours );
			cout<<"OVER TIME PAY  "<<over_time_pay<<endl;
			//on 4 to 5 five rating 10% bonus will be recieved
			
		}
		if(5<=performance_rating<=4){
			bonus_of_performance=base_salary*0.01;
			cout<<"bonus_of_performance: $"<<bonus_of_performance;
		}
		if(5>performance_rating||performance_rating<0){
			cout<<" incorrect performance rating"<<endl;
		}//on servicing greater than 10 bonus will recieve
		if( year_servicing>10){
			
			loyalty_bonus=loyalty_bonus+1000;
		}
		
		
		cout<<"loyalty_bonus = $"<<loyalty_bonus<<endl;
		
		cout<<"bonus_of_performance: $ "<<bonus_of_performance<<endl;
		
		
		total_pay=base_salary+bonus_of_performance+loyalty_bonus+over_time_pay;
		
		cout<<"TOTAL PAY: $"<<total_pay<<endl;//total pay
		
	
	}
	
	
		else{
			cout<<"wrong input"<<endl;
		}
	
	
	
	
	
	
	
	return 0;
	
	

	
}