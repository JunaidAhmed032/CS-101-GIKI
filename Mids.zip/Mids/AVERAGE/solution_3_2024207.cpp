#include<iostream>
#include<string>
using namespace std;

int main(){
	int test_cases;
	cout<<"ENTER TEST CASES: ";
	cin>>test_cases;
	do{
	
	int x=1;
	
	int days;
	cout<<"ENTER NUMBER OF DAYS : ";
	cin>>days;
	bool watered_plant=1;
	while(x<=days){
		cout<<watered_plant;
		
		
	}
		cout<<"watering plant on day";
		
		
		
		
		
}
while(test_cases!=0);
		return 0;
		
		
	}
	
	
