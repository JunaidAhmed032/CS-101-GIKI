#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	int sides[3]; // Array for the sides
	
	// The following three variables are used in the procedure of re-organising the sides by order of greater & smaller length. More on this later in the program
	int first;
	int temp;
	bool isgreat = 0;
	
	// Prompting the user & receiving input
	
	cout << "Enter the length of side A:" << endl;
	cin >> sides[0];
	
	cout << "Enter the length of side B:" << endl;
	cin >> sides[1];
	
	cout << "Enter the length of side C:" << endl;
	cin >> sides[2];
	
	// We attach the elements of the array to letter variables in order to ensure simplicity later in the program
	
	int a = sides[0]; // First side
	int b = sides[1]; // Second side
	int c = sides[2]; // Third side
	
	// The following nested loop finds the greatest side.
	
	for (int i=0; i<=2; i++)
	{
		
		for (int j=0; j<=2; j++)
		{
			if (sides[i] < sides[j]) // Breaks the loop if sides[i] is not the greatest.
			{
			isgreat = 0;
			break;
			}
			
			else // confirms that sides[i] is currently the greatest.
			isgreat = 1;
		}
		
		if (isgreat == 1) // Assigns side[i] as the greatest side (first) for the time being, unless another EVEN GREATER (or EQUAL) SIDE overthrows it.
		first = sides[i];		
	}
	
	// The following two if() sequences ensure that 'c' will always be the longest side, while 'a' & 'b' will be the shorter sides.
	
	if (first == a) // Switches side A with side C, if A is the greatest
	{
	temp = a;
	a = c;
	c = temp;
	}
	
	if (first == b) // Switches side B with side C, if B is the greatest
	{
	temp = b;
	b = c;
	c = temp;
	}
	
	if (a+b <= c) // The sum of the lengths any two sides of a triangle MUST be greater than the length of the third. Otherwise, the three lines cannot form a triangle.
	cout << "\n\nThe given lengths CANNOT form a triangle." << endl;
	
	else 
	{	
	
	// The following three if() sequences check whether the triangle is right, acute or obtuse.
	
	if (pow (a,2) + pow (b,2) == pow (c,2)) // A simple test for spotting right-angled triangles using Pythagoras' theorem
	cout << "\n\nThe given lengths form a RIGHT-ANGLED triangle.";
	
	if (pow (a,2) + pow (b,2) < pow (c,2)) // In an OBTUSE-angled triangle, the sum of the squares of the shorter two sides is LESS than the square of the third.
	cout << "\n\nThe given lengths form an OBTUSE-ANGLED triangle.";
	
	if (pow (a,2) + pow (b,2) > pow (c,2)) // In an ACUTE-angled triangle, the sum of the squares of the shorter two sides is GREATER than the square of the third.
	cout << "\n\nThe given lengths form an ACUTE-ANGLED triangle.";
	
	// The following three if() sequences check whether the triangle is isosceles, equilateral or scalene.
	
	if ((a==b && b!=c) || (a==c && b!=c) || (b==c && a!=b)) // If any two and ONLY two sides are equal, the triangle is isosceles
	cout << " Also, the triangle is ISOSCELES." << endl;
	
	if (a==b && b==c) // If all sides are equal, the triangle is equilateral
	cout << " Also, the triangle is EQUILATERAL." << endl;
	
	if (a!=b && b!=c && c!=a) // If all sides are UNequal, the triangle is scalene
	cout << " Also, the triangle is SCALENE." << endl;
	
	} 
	
	return 0;
}