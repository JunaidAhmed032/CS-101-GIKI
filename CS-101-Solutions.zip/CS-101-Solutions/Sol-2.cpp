#include <iostream>
using namespace std;

int findSurvivor(int n, int k) {
    int terrorists[100]; // Assuming n will not exceed 100
    int size = n;

    // Initialize the array
    for (int i = 0; i < n; i++) {
        terrorists[i] = i + 1;
    }

    int index = 0;
    while (size > 1) {
        index = (index + k) % size;

        // Print the eliminated terrorist
        cout << terrorists[index] << " ";

        // Shift elements to remove the eliminated terrorist
        for (int j = index; j < size - 1; j++) {
            terrorists[j] = terrorists[j + 1];
        }
        size--; // Reduce the size of the group
    }
    cout << endl;

    // Return the last remaining terrorist
    return terrorists[0];
}

int main() {
    int T;
    cin >> T;
    while (T--) {
        int n, k;
        cin >> n >> k;
        cout << "Survivor: " << findSurvivor(n, k - 1) << endl;
    }
    return 0;
}
