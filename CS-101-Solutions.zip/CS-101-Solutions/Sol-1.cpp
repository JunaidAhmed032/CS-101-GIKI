#include <iostream>
using namespace std;

bool isValidTriangle(int a, int b, int c) {
    return (a + b > c && a + c > b && b + c > a);
}

string classifyBySides(int a, int b, int c) {
    if (a == b && b == c) return "Equilateral";
    else if (a == b || b == c || a == c) return "Isosceles";
    return "Scalene";
}

string classifyByAngles(int a, int b, int c) {
    int a2 = a * a, b2 = b * b, c2 = c * c;
    if (a2 + b2 > c2 && a2 + c2 > b2 && b2 + c2 > a2) return "Acute";
    else if (a2 + b2 == c2 || a2 + c2 == b2 || b2 + c2 == a2) return "Right";
    return "Obtuse";
}

void classifyTriangle(int a, int b, int c) {
    if (!isValidTriangle(a, b, c)) {
        cout << "NOT A TRIANGLE" << endl;
        return;
    }
    cout << classifyBySides(a, b, c) << " & " << classifyByAngles(a, b, c) << endl;
}

int main() {
    int testCases[][3] = {
        {1, 2, 3}, {3, 4, 2}, {5, 3, 4},
        {4, 5, 6}, {3, 3, 2}, {5, 3, 3}, {3, 3, 3}
    };
    for (auto &testCase : testCases) {
        classifyTriangle(testCase[0], testCase[1], testCase[2]);
    }
    return 0;
}
