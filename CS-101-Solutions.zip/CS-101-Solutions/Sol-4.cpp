#include <iostream>
using namespace std;

// Function to calculate the square of the distance (avoiding sqrt)
double calculateDistance(double ra1, double dec1, double ra2, double dec2) {
    double raDiff = ra1 - ra2;
    double decDiff = dec1 - dec2;
    return raDiff * raDiff + decDiff * decDiff;
}

int main() {
    // Star data: RA, Dec, Magnitude, Spectral Type
    double ra[4] = {15.2, 16.7, 17.4, 14.3};
    double dec[4] = {40.5, -30.2, 50.1, -20.7};
    double magnitude[4] = {4.1, 3.0, 5.2, 2.5};
    char spectralType[4] = {'G', 'B', 'A', 'M'};

    // Find the Brightest Star
    int brightestIndex = 0;
    for (int i = 1; i < 4; i++) {
        if (magnitude[i] < magnitude[brightestIndex]) {
            brightestIndex = i;
        }
    }

    // Find the Closest Star to RA = 16.0, Dec = -20.0
    double targetRA = 16.0, targetDec = -20.0;
    int closestIndex = 0;
    double minDistance = calculateDistance(ra[0], dec[0], targetRA, targetDec);
    for (int i = 1; i < 4; i++) {
        double distance = calculateDistance(ra[i], dec[i], targetRA, targetDec);
        if (distance < minDistance) {
            closestIndex = i;
            minDistance = distance;
        }
    }

    // Find all Stars of Spectral Type 'G'
    int gIndices[4], gCount = 0;
    for (int i = 0; i < 4; i++) {
        if (spectralType[i] == 'G') {
            gIndices[gCount++] = i;
        }
    }

    // Display the results
    cout << "Brightest Star:" << endl;
    cout << "RA: " << ra[brightestIndex] << ", Dec: " << dec[brightestIndex]
         << ", Magnitude: " << magnitude[brightestIndex]
         << ", Spectral Type: " << spectralType[brightestIndex] << endl;

    cout << "Closest Star to RA: 16.0, Dec: -20.0:" << endl;
    cout << "RA: " << ra[closestIndex] << ", Dec: " << dec[closestIndex]
         << ", Magnitude: " << magnitude[closestIndex]
         << ", Spectral Type: " << spectralType[closestIndex] << endl;

    cout << "Stars of Spectral Type 'G':" << endl;
    for (int i = 0; i < gCount; i++) {
        int index = gIndices[i];
        cout << "RA: " << ra[index] << ", Dec: " << dec[index]
             << ", Magnitude: " << magnitude[index]
             << ", Spectral Type: " << spectralType[index] << endl;
    }

    return 0;
}
